#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

import numpy as np
import cv2

from std_msgs.msg import UInt8MultiArray        ## Input data-type
from std_msgs.msg import UInt8MultiArray        ## Output data-type
from geometry_msgs.msg import Twist

from std_msgs.msg import MultiArrayLayout, MultiArrayDimension

class myNode(Node):

    def __init__(self):
        super().__init__("cam_obj_detect")   # Names the node

        self.create_subscription(UInt8MultiArray, "/frame", self.callback, 10)

        self.pub_rel_pos = self.create_publisher(Twist, "/rel_pos", 10)
        self.pub_cutout = self.create_publisher(UInt8MultiArray, "/cutout", 10)
        # Datatype, Topic name, Callback function, buffer size

    def callback(self, msg : UInt8MultiArray):
        print("reached")
        list = msg.data     ## Gets the list from the msg
        array : cv2.OutputArray = np.asarray(list).reshape((msg.layout.dim[0].size, msg.layout.dim[1].size, msg.layout.dim[2].size))    ## Convert the list to an OpenCV format

        ## Step 1: Converting RGB to HSL
        hls = cv2.cvtColor(array, cv2.COLOR_BGR2HLS)

        ## Step 2: Creating a masker, focussed on light parts of the img
        Lchannel = hls[:,:,1]
        mask = cv2.inRange(Lchannel, 200, 255)
        ## Step 3: Blurring the masker to filter out noise
        mask_blur = cv2.boxFilter(mask, -1, (5, 5))

        ## Step 4: Detecting contours within the blurred mask
        ret, thresh = cv2.threshold(mask_blur, 180, 255, cv2.THRESH_OTSU)
        contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        boxes = []

        for c in contours:
            area = cv2.contourArea(c)
            perimeter = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, 0.01 * perimeter, True)

            ## Step 5: Defined parameters to determine if a contour is a "medicijndoosje"
            isBox = len(approx) >= 4 and len(approx) <= 6 and area > 3000 and area < 200000

            if isBox:
                boxes.append(c)

        for b in boxes:
            x, y, w, h = cv2.boundingRect(b)
            cropped = array[y:h + y, x:w + x]

            X = x + w / 2
            Y = y + h / 2

            ## Define the message for /rel_pos
            msg_rel_pos : Twist

            ## If-statements to determine data for the message
            if      X < array.shape[1] / 2:
                #Xdif = 1 - (X / self.Xdivide)
                msg_rel_pos.angular.z = 50
                #pass
            elif    X > array.shape[1] / 2:
                #Xdif = 1 - (array.shape[0] - X) / self.Xdivide
                msg_rel_pos.angular.z = -50
                #pass
            if      Y < array.shape[0] / 2:
                #Ydif = 1 - (Y / self.Ydivide)
                msg_rel_pos.angular.x = 50
                #pass
            elif    Y > array.shape[0] / 2:
                #Ydif = 1 - (array.shape[0] - Y) / self.Ydivide
                msg_rel_pos.angular.x = -50
                #pass

            ## Define the message for /cutout
            msg_cutout : UInt8MultiArray
            msg_cutout.data = cropped.flatten().tolist()

            #region
            ## Definition of the layout of the UInt8MultiArray
            layout = MultiArrayLayout()

            layout.dim.append(MultiArrayDimension())
            layout.dim.append(MultiArrayDimension())
            layout.dim.append(MultiArrayDimension())

            layout.dim[0].label = "height"
            layout.dim[0].size = cropped.shape[0]
            layout.dim[0].stride = cropped.shape[2] * cropped.shape[1] * cropped.shape[0]

            layout.dim[1].label = "width"
            layout.dim[1].size = cropped.shape[1]
            layout.dim[1].stride = cropped.shape[2] * cropped.shape[1]

            layout.dim[2].label = "channel"
            layout.dim[2].size = cropped.shape[2]
            layout.dim[2].stride = cropped.shape[2]

            layout.data_offset = 0
            #endregion

            msg_cutout.layout = layout

            ## Publish the messages
            self.pub_rel_pos.publish(msg_rel_pos)
            self.get_logger().info(msg_rel_pos.data)
            self.pub_cutout.publish(msg_cutout)

            break       # For simplicity only handles 1 box


        #print("stop")
        
        
def main(args = None):
    rclpy.init(args=args)   # Init ROS2

    node = myNode()         # Creates the node
    rclpy.spin_once(node)   # Loops the node

    rclpy.shutdown()        # Shutdown ROS2


if __name__ == '__main__':
    main()